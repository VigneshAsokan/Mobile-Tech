package com.vignesh.mtgame;

import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Animation;
import com.badlogic.gdx.graphics.g2d.Batch;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.graphics.g2d.freetype.FreeTypeFontGenerator;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.badlogic.gdx.math.MathUtils;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.math.Vector2;

import java.lang.reflect.Array;
import java.util.ArrayList;

public class MainGame extends ApplicationAdapter {
	private Integer Level;
	private static final int FRAME_COLS = 16, FRAME_ROWS = 1;
	public int InputPos;
	private Animation<TextureRegion> Player_animation;
	private SpriteBatch batch;
	private Sprite Player;
	private Sprite[] Seq_numbers,NSeq_numbers;

	private Sprite _BackGround1, _BackGround2,Menu_BG,back;
	private Texture Player_texture,backGround,MENU_BG;

	private float stateTime;
	private float _BackGroundX, _BackGroundY1, _BackGroundY2, speed;
	private float PlayerX, PlayerY,PlayerX_left, PlayerX_right;
	public FreeTypeFontGenerator.FreeTypeFontParameter params,paramsG;

	private float[] Seq_NX,NSeq_NX;
	private float[] Seq_NY,NSeq_NY;
	private Integer score, Lives, PosY;
	private Boolean GameOver;
	private BitmapFont scoreFont,LivesFont,GameOver_Font;
	private Rectangle Seq_N1Rect, Seq_N2Rect, Seq_N3Rect,Seq_N4Rect,Seq_N5Rect,Seq_N6Rect, Seq_N7Rect, Seq_N8Rect,Seq_N9Rect,Seq_N10Rect,Seq_N11Rect,Seq_N12Rect, PlayerRect;
	private Rectangle NSeq_N1Rect, NSeq_N2Rect, NSeq_N3Rect,NSeq_N4Rect,NSeq_N5Rect,NSeq_N6Rect, NSeq_N7Rect, NSeq_N8Rect,NSeq_N9Rect,NSeq_N10Rect,NSeq_N11Rect,NSeq_N12Rect;
	private ShapeRenderer shapeRenderer;
	public int Load ;


	@Override
	public void create () {
		Load=1;
		batch = new SpriteBatch();

		//Call ROLL ANIMATION
		Player_texture = new Texture(Gdx.files.internal("Ball.png"));
		back = new Sprite(new Texture(Gdx.files.internal("back.png")));
		PlayerRoll();


		//LEVEL ONE
		MENU_BG=new Texture((Gdx.files.internal("Menu.png")));
		Menu_BG= new Sprite(MENU_BG);
		backGround = new Texture((Gdx.files.internal("BG1.png")));
		_BackGround1 = new Sprite(backGround);
		_BackGround2 = new Sprite(backGround);

		Seq_NY=new float[20];
		Seq_NX=new float[20];
		NSeq_NY=new float[20];
		NSeq_NX=new float[20];
		setValues();

		SetSprite_L1();




	}

	private void PlayerRoll(){
		TextureRegion[][] tmp = TextureRegion.split(Player_texture,
				Player_texture.getWidth() / FRAME_COLS,
				Player_texture.getHeight() / FRAME_ROWS);

		TextureRegion[] RollFrames = new TextureRegion[FRAME_COLS * FRAME_ROWS];
		int index = 0;
		for (int i = 0; i < FRAME_ROWS; i++) {
			for (int j = 0; j < FRAME_COLS; j++) {
				RollFrames[index++] = tmp[i][j];
			}
		}

		// Initialize the Animation with the frame interval and array of frames
		Player_animation = new Animation<TextureRegion>(1/25f, RollFrames);
		Player_animation.setPlayMode(Animation.PlayMode.REVERSED);
		stateTime = 0f;
	}

	public void setValues(){

		GameOver=false;
		//Player
		PlayerX= Gdx.graphics.getWidth()/2-50;
		PlayerY= 100;
		PlayerX_left=100;
		PlayerX_right=900;

		//Background
		_BackGroundX = 0;
		_BackGroundY1 = 0;
		_BackGroundY2 = 875;
		speed = 900;

		//Back
		back.setPosition(100,1900);


		_BackGround1.setPosition(_BackGroundX, _BackGroundY1);
		_BackGround1.setSize(1200, 2160);
		_BackGround2.setPosition(_BackGroundX, _BackGroundY2);
		_BackGround2.setSize(1200, 2160);

		FreeTypeFontGenerator generator = new FreeTypeFontGenerator(Gdx.files.internal("font/ComingSoon.ttf"));
		 params = new FreeTypeFontGenerator.FreeTypeFontParameter();
		 paramsG = new FreeTypeFontGenerator.FreeTypeFontParameter();
		for(int i=0;i<20;i++){
			Seq_NX[i]=getRandomSeq_NX();
		}
		for(int i=0;i<13;i++){
			NSeq_NX[i]=getRandomSeq_NX();
		}
		PosY=1700;
		Seq_NY[0]=PosY;
		Seq_NY[1]=PosY*2;
		Seq_NY[2]=PosY*3;
		Seq_NY[3]=PosY*4;
		Seq_NY[4]=PosY*5;
		Seq_NY[5]=PosY*6;
		Seq_NY[6]=PosY*7;
		Seq_NY[7]=PosY*8;
		Seq_NY[8]=PosY*9;
		Seq_NY[9]=PosY*10;
		Seq_NY[10]=PosY*11;
		Seq_NY[11]=PosY*12;
		Seq_NY[12]=PosY*13;

		for(int i=0;i<20;i++) {
			NSeq_NY[i] = Seq_NY[i]+750;
		}

			score = 0;
			Lives=3;
		shapeRenderer = new ShapeRenderer();
		shapeRenderer.setAutoShapeType(true);
		PlayerRect = new com.badlogic.gdx.math.Rectangle(0, 0, 100, 100);
		//SEQ
		Seq_N1Rect = new com.badlogic.gdx.math.Rectangle(Seq_NX[0], Seq_NY[0], 140, 140);
		Seq_N2Rect = new com.badlogic.gdx.math.Rectangle(Seq_NX[1], Seq_NY[1], 140, 140);
		Seq_N3Rect = new com.badlogic.gdx.math.Rectangle(Seq_NX[2], Seq_NY[2], 140, 140);
		Seq_N4Rect = new com.badlogic.gdx.math.Rectangle(Seq_NX[3], Seq_NY[3], 140, 140);
		Seq_N5Rect = new com.badlogic.gdx.math.Rectangle(Seq_NX[4], Seq_NY[4], 140, 140);
		Seq_N6Rect = new com.badlogic.gdx.math.Rectangle(Seq_NX[5], Seq_NY[5], 140, 140);
		Seq_N7Rect = new com.badlogic.gdx.math.Rectangle(Seq_NX[6], Seq_NY[6], 140, 140);
		Seq_N8Rect = new com.badlogic.gdx.math.Rectangle(Seq_NX[7], Seq_NY[7], 140, 140);
		Seq_N9Rect = new com.badlogic.gdx.math.Rectangle(Seq_NX[8], Seq_NY[8], 140, 140);
		Seq_N10Rect = new com.badlogic.gdx.math.Rectangle(Seq_NX[9], Seq_NY[9], 140, 140);
		Seq_N11Rect = new com.badlogic.gdx.math.Rectangle(Seq_NX[10], Seq_NY[10], 140, 140);
		Seq_N12Rect = new com.badlogic.gdx.math.Rectangle(Seq_NX[11], Seq_NY[11], 140, 140);

		//NON_SEQ
		NSeq_N1Rect = new com.badlogic.gdx.math.Rectangle(NSeq_NX[0], NSeq_NY[0], 140, 140);
		NSeq_N2Rect = new com.badlogic.gdx.math.Rectangle(NSeq_NX[1], NSeq_NY[1], 140, 140);
		NSeq_N3Rect = new com.badlogic.gdx.math.Rectangle(NSeq_NX[2], NSeq_NY[2], 140, 140);
		NSeq_N4Rect = new com.badlogic.gdx.math.Rectangle(NSeq_NX[3], NSeq_NY[3], 140, 140);
		NSeq_N5Rect = new com.badlogic.gdx.math.Rectangle(NSeq_NX[4], NSeq_NY[4], 140, 140);
		NSeq_N6Rect = new com.badlogic.gdx.math.Rectangle(NSeq_NX[5], NSeq_NY[5], 140, 140);
		NSeq_N7Rect = new com.badlogic.gdx.math.Rectangle(NSeq_NX[6], NSeq_NY[6], 140, 140);
		NSeq_N8Rect = new com.badlogic.gdx.math.Rectangle(NSeq_NX[7], NSeq_NY[7], 140, 140);
		NSeq_N9Rect = new com.badlogic.gdx.math.Rectangle(NSeq_NX[8], NSeq_NY[8], 140, 140);
		NSeq_N10Rect = new com.badlogic.gdx.math.Rectangle(NSeq_NX[9], NSeq_NY[9], 140, 140);
		NSeq_N11Rect = new com.badlogic.gdx.math.Rectangle(NSeq_NX[10], NSeq_NY[10], 140, 140);
		NSeq_N12Rect = new com.badlogic.gdx.math.Rectangle(NSeq_NX[11], NSeq_NY[11], 140, 140);


		params.size = 100;
		params.color = Color.WHITE;
		paramsG.size = 150;
		paramsG.color = Color.BLACK;
		scoreFont = generator.generateFont(params);
		LivesFont = generator.generateFont(params);
		GameOver_Font = generator.generateFont(paramsG);
	}

	public void SetSprite_L1(){
		Seq_numbers = new Sprite[13];
		Seq_numbers[0]=new Sprite(new Texture("Level1/Seq/1.png"));
		Seq_numbers[1]=new Sprite(new Texture("Level1/Seq/1.png"));
		Seq_numbers[2]=new Sprite(new Texture("Level1/Seq/2.png"));
		Seq_numbers[3]=new Sprite(new Texture("Level1/Seq/3.png"));
		Seq_numbers[4]=new Sprite(new Texture("Level1/Seq/5.png"));
		Seq_numbers[5]=new Sprite(new Texture("Level1/Seq/8.png"));
		Seq_numbers[6]=new Sprite(new Texture("Level1/Seq/13.png"));
		Seq_numbers[7]=new Sprite(new Texture("Level1/Seq/21.png"));
		Seq_numbers[8]=new Sprite(new Texture("Level1/Seq/34.png"));
		Seq_numbers[9]=new Sprite(new Texture("Level1/Seq/55.png"));
		Seq_numbers[10]=new Sprite(new Texture("Level1/Seq/89.png"));
		Seq_numbers[11]=new Sprite(new Texture("Level1/Seq/144.png"));
		Seq_numbers[12]=new Sprite(new Texture("Level1/Seq/233.png"));
		NSeq_numbers = new Sprite[13];
		NSeq_numbers[0]=new Sprite(new Texture("Level1/Non/4.png"));
		NSeq_numbers[1]=new Sprite(new Texture("Level1/Non/6.png"));
		NSeq_numbers[2]=new Sprite(new Texture("Level1/Non/9.png"));
		NSeq_numbers[3]=new Sprite(new Texture("Level1/Non/12.png"));
		NSeq_numbers[4]=new Sprite(new Texture("Level1/Non/12.png"));
		NSeq_numbers[5]=new Sprite(new Texture("Level1/Non/23.png"));
		NSeq_numbers[6]=new Sprite(new Texture("Level1/Non/24.png"));
		NSeq_numbers[7]=new Sprite(new Texture("Level1/Non/33.png"));
		NSeq_numbers[8]=new Sprite(new Texture("Level1/Non/45.png"));
		NSeq_numbers[9]=new Sprite(new Texture("Level1/Non/59.png"));
		NSeq_numbers[10]=new Sprite(new Texture("Level1/Non/33.png"));
		NSeq_numbers[11]=new Sprite(new Texture("Level1/Non/45.png"));
		NSeq_numbers[12]=new Sprite(new Texture("Level1/Non/59.png"));
	}

	@Override
	public void render () {
		Gdx.gl.glClearColor(1, 0, 0, 1);
		Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);

		update(Gdx.graphics.getDeltaTime());
		if(Load==1)
			DrawLev();
	}

	public  void DrawLev(){
		batch.begin();

		_BackGround1.draw(batch);
		_BackGround2.draw(batch);
		back.draw(batch);
		Player.draw(batch);
		scoreFont.draw(batch, score.toString(), 420, 2000);
		LivesFont.draw(batch,"Lives : " + Lives.toString(), 620, 2000);
		if(GameOver) {
			GameOver_Font.draw(batch, "Game Over", 200, 1200);
		}
		for (int i =0;i<13;i++) {
			Seq_numbers[i].draw(batch);
		}
		for (int i =0;i<13;i++) {
			NSeq_numbers[i].draw(batch);
		}

		batch.end();

	}
	private void update(float deltaTime) {
		if(GameOver){
			return;
		}
		stateTime += deltaTime;
		updateBG(deltaTime);
		updateBall(deltaTime);
		updateNumbers(deltaTime);

		checkCollision();

		if(Lives==0){
			GameOver=true;
		}

	}
	private void checkCollision() {
		//SEQ
		if (Seq_N1Rect.overlaps(PlayerRect)){
			score+=10;
			Seq_NY[0]=99999;
		}
		if (Seq_N2Rect.overlaps(PlayerRect)){
			score+=10;
			Seq_NY[1]=99999;
		}
		if (Seq_N3Rect.overlaps(PlayerRect)){
			score+=10;
			Seq_NY[2]=99999;
		}
		if (Seq_N4Rect.overlaps(PlayerRect)){
			score+=10;
			Seq_NY[3]=99999;
		}
		if (Seq_N5Rect.overlaps(PlayerRect)){
			score+=10;
			Seq_NY[4]=99999;
		}
		if (Seq_N6Rect.overlaps(PlayerRect)){
			score+=10;
			Seq_NY[5]=99999;
		}
		if (Seq_N7Rect.overlaps(PlayerRect)){
			score+=10;
			Seq_NY[6]=99999;
		}
		if (Seq_N8Rect.overlaps(PlayerRect)){
			score+=10;
			Seq_NY[7]=99999;
		}
		if (Seq_N9Rect.overlaps(PlayerRect)){
			score+=10;
			Seq_NY[8]=99999;
		}
		if (Seq_N10Rect.overlaps(PlayerRect)){
			score+=10;
			Seq_NY[9]=99999;
		}
		if (Seq_N11Rect.overlaps(PlayerRect)){
			score+=10;
			Seq_NY[10]=99999;
		}
		if (Seq_N12Rect.overlaps(PlayerRect)){
			score+=10;
			Seq_NY[11]=99999;
			Seq_NY[0]=PosY;
			Seq_NY[1]=PosY*2;
			Seq_NY[2]=PosY*3;
			Seq_NY[3]=PosY*4;
			Seq_NY[4]=PosY*5;
			Seq_NY[5]=PosY*6;
			Seq_NY[6]=PosY*7;
			Seq_NY[7]=PosY*8;
			Seq_NY[8]=PosY*9;
			Seq_NY[9]=PosY*10;
			Seq_NY[10]=PosY*11;
			Seq_NY[11]=PosY*12;
			Seq_NY[12]=PosY*13;
			for(int i=0;i<20;i++) {

				NSeq_NY[i] = Seq_NY[i]+750;
			}
		}
		//NON-SEQ
		if (NSeq_N1Rect.overlaps(PlayerRect)){
			Lives-=1;
			NSeq_NY[0]=99999;
		}
		if (NSeq_N2Rect.overlaps(PlayerRect)){
			Lives-=1;
			NSeq_NY[1]=99999;
		}
		if (NSeq_N3Rect.overlaps(PlayerRect)){
			Lives-=1;
			NSeq_NY[2]=99999;
		}
		if (NSeq_N4Rect.overlaps(PlayerRect)){
			Lives-=1;
			NSeq_NY[3]=99999;
		}
		if (NSeq_N5Rect.overlaps(PlayerRect)){
			Lives-=1;
			NSeq_NY[4]=99999;
		}
		if (NSeq_N6Rect.overlaps(PlayerRect)){
			Lives-=1;
			NSeq_NY[5]=99999;
		}
		if (NSeq_N7Rect.overlaps(PlayerRect)){
			Lives-=1;
			NSeq_NY[6]=99999;
		}
		if (NSeq_N8Rect.overlaps(PlayerRect)){
			Lives-=1;
			NSeq_NY[7]=99999;
		}
		if (NSeq_N9Rect.overlaps(PlayerRect)){
			Lives-=1;
			NSeq_NY[8]=99999;
		}
		if (NSeq_N10Rect.overlaps(PlayerRect)){
			Lives-=1;
			NSeq_NY[9]=99999;
		}
		if (NSeq_N11Rect.overlaps(PlayerRect)){
			Lives-=1;
			NSeq_NY[10]=99999;
		}
	}
	private float getRandomSeq_NX(){ //this function will generate some random X value
		//float retVal = PlayerX_left;
		float retVal=MathUtils.random(100,900);
		return retVal;
	}
	
	private void updateNumbers(float deltaTime){

		for(int i=0;i<13;i++){
			Seq_NY[i]-=deltaTime*speed;
			NSeq_NY[i]-=deltaTime*speed;

		}
		if(Seq_NY[12]<-200){
			Seq_NY[0]=PosY;
			Seq_NY[1]=PosY*2;
			Seq_NY[2]=PosY*3;
			Seq_NY[3]=PosY*4;
			Seq_NY[4]=PosY*5;
			Seq_NY[5]=PosY*6;
			Seq_NY[6]=PosY*7;
			Seq_NY[7]=PosY*8;
			Seq_NY[8]=PosY*9;
			Seq_NY[9]=PosY*10;
			Seq_NY[10]=PosY*11;
			Seq_NY[11]=PosY*12;
			Seq_NY[12]=PosY*13;
			for(int i=0;i<20;i++) {

				NSeq_NY[i] = Seq_NY[i]+750;
			}
		}
		//Seq
		Seq_N1Rect.setPosition(Seq_NX[0]+10, Seq_NY[0]+10);
		Seq_N2Rect.setPosition(Seq_NX[1]+10, Seq_NY[1]+10);
		Seq_N3Rect.setPosition(Seq_NX[2]+10, Seq_NY[2]+10);
		Seq_N4Rect.setPosition(Seq_NX[3]+10, Seq_NY[3]+10);
		Seq_N5Rect.setPosition(Seq_NX[4]+10, Seq_NY[4]+10);
		Seq_N6Rect.setPosition(Seq_NX[5]+10, Seq_NY[5]+10);
		Seq_N7Rect.setPosition(Seq_NX[6]+10, Seq_NY[6]+10);
		Seq_N8Rect.setPosition(Seq_NX[7]+10, Seq_NY[7]+10);
		Seq_N9Rect.setPosition(Seq_NX[8]+10, Seq_NY[8]+10);
		Seq_N10Rect.setPosition(Seq_NX[9]+10, Seq_NY[9]+10);
		Seq_N11Rect.setPosition(Seq_NX[10]+10, Seq_NY[10]+10);
		Seq_N12Rect.setPosition(Seq_NX[11]+10, Seq_NY[11]+10);
		//NON Seq
		NSeq_N1Rect.setPosition(NSeq_NX[0]+10, NSeq_NY[0]+10);
		NSeq_N2Rect.setPosition(NSeq_NX[1]+10, NSeq_NY[1]+10);
		NSeq_N3Rect.setPosition(NSeq_NX[2]+10, NSeq_NY[2]+10);
		NSeq_N4Rect.setPosition(NSeq_NX[3]+10, NSeq_NY[3]+10);
		NSeq_N5Rect.setPosition(NSeq_NX[4]+10, NSeq_NY[4]+10);
		NSeq_N6Rect.setPosition(NSeq_NX[5]+10, NSeq_NY[5]+10);
		NSeq_N7Rect.setPosition(NSeq_NX[6]+10, NSeq_NY[6]+10);
		NSeq_N8Rect.setPosition(NSeq_NX[7]+10, NSeq_NY[7]+10);
		NSeq_N9Rect.setPosition(NSeq_NX[8]+10, NSeq_NY[8]+10);
		NSeq_N10Rect.setPosition(NSeq_NX[9]+10, NSeq_NY[9]+10);
		NSeq_N11Rect.setPosition(NSeq_NX[10]+10, NSeq_NY[10]+10);
		NSeq_N12Rect.setPosition(NSeq_NX[11]+10, NSeq_NY[11]+10);

		if(Lives==0){
			GameOver=true;
		}
		for(int i=0;i<13;i++){
			Seq_numbers[i].setPosition(Seq_NX[i], Seq_NY[i]);
		}
		for(int i=0;i<13;i++){
			NSeq_numbers[i].setPosition(NSeq_NX[i], NSeq_NY[i]);
		}
	}
	
	private void updateBG(float deltaTime){
		_BackGroundY2 -= deltaTime * speed;
		_BackGroundY1 -= deltaTime * speed;

		if(_BackGroundY1 < -876)
			_BackGroundY1 += 876 +(_BackGroundY2 + 876);

		if(_BackGroundY2 < -876)
			_BackGroundY2 += 876 +(_BackGroundY1 + 876);

		_BackGround1.setPosition(_BackGroundX, _BackGroundY1);
		_BackGround2.setPosition(_BackGroundX, _BackGroundY2);
	}

	private void updateBall(float deltaTime){
		//Set Animation
		stateTime+=deltaTime;
		TextureRegion currentFrame_Player = Player_animation.getKeyFrame(stateTime, true);
		Player= new Sprite(currentFrame_Player);
		Player.setPosition(PlayerX,PlayerY);
		PlayerRect.setPosition(PlayerX, PlayerY);
		int width= Gdx.graphics.getWidth()/2;
		if(Gdx.input.isTouched()){
			InputPos= Gdx.input.getX();
			if(width>InputPos && PlayerX!= PlayerX_left){
				PlayerX-=10;
			}
			if(width<InputPos && PlayerX!= PlayerX_right) {
				PlayerX+=10;

			}
		}
		if(Gdx.input.isKeyPressed(Input.Keys.LEFT) && PlayerX!= PlayerX_left){
			PlayerX-=10;

		}
		if(Gdx.input.isKeyPressed(Input.Keys.RIGHT) && PlayerX!= PlayerX_right){
			PlayerX+=10;

		}
		Player.setPosition(PlayerX,PlayerY);

	}

	@Override
	public void dispose () {
		batch.dispose();
		Player_texture.dispose();


	}
}
